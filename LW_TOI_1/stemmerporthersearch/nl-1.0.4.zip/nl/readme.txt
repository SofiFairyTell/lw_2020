This is the NL numerical library
For documentation (in Russian) see doc\html\index.html
For version see file version