//{{NO_DEPENDENCIES}}
// ���������� ����, ��������� � Microsoft Visual C++.
// ������������ lw_os_21.rc
//
#define IDD_DIALOG1                     101
#define IDR_MENU1                       102
#define IDR_ACCELERATOR1                104
#define IDD_DIALOG2                     105
#define IDC_EDIT1                       1001
#define IDC_MONTHCALENDAR1              1002
#define IDC_LIST1                       1003
#define IDC_SPIN1                       1004
#define IDC_EDIT2                       1005
#define IDC_EDIT3                       1006
#define ID_NEW_RECORD                   40001
#define ID_NEW_RECORD2                  40002
#define ID_DEL_RECORD                   40003
#define ID_FIND_RECORD                  40004
#define ID_FORMAT_FONT                  40005
#define ID_EDIT                         40012
#define ID_40013                        40013
#define ID_40014                        40014
#define ID_40016                        40016
#define ID_40017                        40017
#define ID_SAVE_AS                      40019
#define ID_REPLACE                      40020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40023
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
